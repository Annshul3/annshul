#ifndef FUNCTIONS_H
#define FUNCTIONS_H

void displaystudents();
void addstudents();
void calculateaverage();

#endif